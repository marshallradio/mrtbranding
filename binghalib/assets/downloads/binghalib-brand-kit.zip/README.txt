Binghalib Group brand kit (prototype)
Source: Binghalib Group Profile, April 2025. Logos extracted from the PDF; confirm against master artwork before print.
Guidelines: https://sbinghalib.github.io/binghalib/
AI agents: https://sbinghalib.github.io/binghalib/AGENTS.md
